package com.jellyphoto.wallpaper

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Shader
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.MotionEvent
import android.view.SurfaceHolder
import java.io.File
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

class JellyWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = JellyEngine()

    inner class JellyEngine : Engine(), SensorEventListener {

        private val cols = 18
        private val rows = 30
        private val n = (cols + 1) * (rows + 1)
        private val overscan = 0.05f

        private val rest = FloatArray(n * 2)
        private val cur = FloatArray(n * 2)
        private val disp = FloatArray(n * 2)
        private val vel = FloatArray(n * 2)

        private val handler = Handler(Looper.getMainLooper())
        private val paint = Paint(Paint.FILTER_BITMAP_FLAG)

        private var bmp: Bitmap? = null
        private var sw = 0
        private var sh = 0
        private var isShown = false
        private var running = false
        private var calmFrames = 0
        private var lastTime = 0L
        private var photoStamp = -1L

        private var hasTouch = false
        private var lastTx = 0f
        private var lastTy = 0f

        private var hasPrev = false
        private var prevX = 0f
        private var prevY = 0f
        private var prevZ = 0f
        private var lastXOffset = -1f

        private val sensorManager: SensorManager by lazy {
            getSystemService(SENSOR_SERVICE) as SensorManager
        }

        private val frame = object : Runnable {
            override fun run() {
                if (!isShown) {
                    running = false
                    return
                }
                val now = System.nanoTime()
                val dt = min((now - lastTime) / 1.0e9f, 0.033f)
                lastTime = now
                val calm = step(dt)
                drawFrame()
                if (calm) calmFrames++ else calmFrames = 0
                if (calmFrames > 20 && !hasTouch) {
                    running = false
                    return
                }
                handler.postDelayed(this, 16)
            }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            setTouchEventsEnabled(true)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            sw = width
            sh = height
            buildScene()
            drawFrame()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            isShown = visible
            if (visible) {
                val f = File(filesDir, "photo.jpg")
                val stamp = if (f.exists()) f.lastModified() else 0L
                if (sw > 0 && stamp != photoStamp) buildScene()
                val acc = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
                if (acc != null) {
                    sensorManager.registerListener(this, acc, SensorManager.SENSOR_DELAY_GAME)
                }
                hasPrev = false
                drawFrame()
            } else {
                sensorManager.unregisterListener(this)
                handler.removeCallbacks(frame)
                running = false
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            isShown = false
            handler.removeCallbacks(frame)
            running = false
            sensorManager.unregisterListener(this)
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            isShown = false
            handler.removeCallbacks(frame)
            sensorManager.unregisterListener(this)
            bmp?.recycle()
            bmp = null
            super.onDestroy()
        }

        // ---------- картинка и сетка ----------

        private fun buildScene() {
            if (sw <= 0 || sh <= 0) return
            val file = File(filesDir, "photo.jpg")
            photoStamp = if (file.exists()) file.lastModified() else 0L
            val src: Bitmap? = if (file.exists()) BitmapFactory.decodeFile(file.path) else null

            val w = (sw * (1f + 2f * overscan)).roundToInt()
            val h = (sh * (1f + 2f * overscan)).roundToInt()
            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            if (src != null) {
                val s = max(w.toFloat() / src.width, h.toFloat() / src.height)
                val dx = (w - src.width * s) / 2f
                val dy = (h - src.height * s) / 2f
                val m = Matrix()
                m.postScale(s, s)
                m.postTranslate(dx, dy)
                c.drawBitmap(src, m, paint)
                src.recycle()
            } else {
                val p = Paint(Paint.ANTI_ALIAS_FLAG)
                p.shader = LinearGradient(
                    0f, 0f, w.toFloat(), h.toFloat(),
                    Color.rgb(255, 120, 150), Color.rgb(120, 90, 255), Shader.TileMode.CLAMP
                )
                c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
            }
            bmp?.recycle()
            bmp = out

            val ox = -sw * overscan
            val oy = -sh * overscan
            for (j in 0..rows) {
                for (i in 0..cols) {
                    val k = (j * (cols + 1) + i) * 2
                    rest[k] = ox + w.toFloat() * i / cols
                    rest[k + 1] = oy + h.toFloat() * j / rows
                }
            }
            disp.fill(0f)
            vel.fill(0f)
        }

        // ---------- физика желе ----------

        // Возвращает true, если всё практически успокоилось.
        private fun step(dt: Float): Boolean {
            val spring = 70f
            val couple = 420f
            val damp = 3.2f
            val maxD = sw * overscan * 0.9f
            val stride = (cols + 1) * 2

            for (j in 0..rows) {
                for (i in 0..cols) {
                    val k = (j * (cols + 1) + i) * 2
                    var sx = 0f
                    var sy = 0f
                    var cnt = 0
                    if (i > 0) { sx += disp[k - 2]; sy += disp[k - 1]; cnt++ }
                    if (i < cols) { sx += disp[k + 2]; sy += disp[k + 3]; cnt++ }
                    if (j > 0) { sx += disp[k - stride]; sy += disp[k - stride + 1]; cnt++ }
                    if (j < rows) { sx += disp[k + stride]; sy += disp[k + stride + 1]; cnt++ }
                    val ax = -spring * disp[k] + couple * (sx / cnt - disp[k]) - damp * vel[k]
                    val ay = -spring * disp[k + 1] + couple * (sy / cnt - disp[k + 1]) - damp * vel[k + 1]
                    vel[k] += ax * dt
                    vel[k + 1] += ay * dt
                }
            }

            var maxV = 0f
            var maxDisp = 0f
            for (k in 0 until n * 2) {
                vel[k] = vel[k].coerceIn(-1800f, 1800f)
                disp[k] = (disp[k] + vel[k] * dt).coerceIn(-maxD, maxD)
                maxV = max(maxV, abs(vel[k]))
                maxDisp = max(maxDisp, abs(disp[k]))
            }
            return maxV < 2f && maxDisp < 0.5f
        }

        private fun pokeAt(x: Float, y: Float, ivx: Float, ivy: Float, radius: Float) {
            val r2 = radius * radius
            for (idx in 0 until n) {
                val k = idx * 2
                val dx = rest[k] - x
                val dy = rest[k + 1] - y
                val dd = dx * dx + dy * dy
                if (dd < r2 * 4f) {
                    val f = exp(-dd / r2)
                    vel[k] += ivx * f
                    vel[k + 1] += ivy * f
                }
            }
        }

        // Тряска всего экрана: в центре сильнее, у краёв слабее.
        private fun shake(ix: Float, iy: Float) {
            for (j in 0..rows) {
                for (i in 0..cols) {
                    val wgt = 0.4f + 0.6f *
                        sin(PI.toFloat() * j / rows) * sin(PI.toFloat() * i / cols)
                    val k = (j * (cols + 1) + i) * 2
                    vel[k] += ix * wgt
                    vel[k + 1] += iy * wgt
                }
            }
        }

        private fun kick() {
            calmFrames = 0
            if (!running && isShown) {
                running = true
                lastTime = System.nanoTime()
                handler.post(frame)
            }
        }

        // ---------- рисование ----------

        private fun drawFrame() {
            val b = bmp ?: return
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = if (Build.VERSION.SDK_INT >= 26) holder.lockHardwareCanvas()
                else holder.lockCanvas()
            } catch (e: Exception) {
                canvas = null
            }
            if (canvas == null) return
            try {
                canvas.drawColor(Color.BLACK)
                for (k in 0 until n * 2) cur[k] = rest[k] + disp[k]
                canvas.drawBitmapMesh(b, cols, rows, cur, 0, null, 0, paint)
            } catch (e: Exception) {
                // кадр пропущен
            } finally {
                try {
                    holder.unlockCanvasAndPost(canvas)
                } catch (e: Exception) {
                    // поверхность уже закрыта
                }
            }
        }

        // ---------- ввод ----------

        override fun onTouchEvent(event: MotionEvent) {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    hasTouch = true
                    lastTx = event.x
                    lastTy = event.y
                    pokeAt(event.x, event.y, 0f, 300f, sw * 0.2f)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.x - lastTx
                    val dy = event.y - lastTy
                    lastTx = event.x
                    lastTy = event.y
                    pokeAt(event.x, event.y, dx * 25f, dy * 25f, sw * 0.18f)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> hasTouch = false
            }
            kick()
        }

        override fun onOffsetsChanged(
            xOffset: Float, yOffset: Float, xOffsetStep: Float, yOffsetStep: Float,
            xPixelOffset: Int, yPixelOffset: Int
        ) {
            if (lastXOffset >= 0f) {
                val delta = xOffset - lastXOffset
                if (abs(delta) > 0.0001f) {
                    shake(-delta * sw * 20f, 0f)
                    kick()
                }
            }
            lastXOffset = xOffset
        }

        override fun onSensorChanged(event: SensorEvent) {
            val x = event.values[0]
            val y = event.values[1]
            val z = event.values[2]
            if (!hasPrev) {
                prevX = x; prevY = y; prevZ = z
                hasPrev = true
                return
            }
            val jx = x - prevX
            val jy = y - prevY
            val jz = z - prevZ
            prevX = x; prevY = y; prevZ = z
            val mag = sqrt(jx * jx + jy * jy + jz * jz)
            if (mag > 0.8f) {
                shake(-jx * 40f, jy * 40f)
                kick()
            }
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }
}
