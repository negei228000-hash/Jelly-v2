package com.jellyphoto.wallpaper

import android.app.Activity
import android.app.WallpaperManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File

class MainActivity : Activity() {

    private lateinit var status: TextView
    private val pickCode = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setPadding(pad, pad * 2, pad, pad)

        val title = TextView(this)
        title.text = "Jelly Обои"
        title.textSize = 28f
        title.gravity = Gravity.CENTER
        root.addView(title)

        val hint = TextView(this)
        hint.text = "1. Выбери фото\n2. Поставь живые обои\nПотом трясёшь телефон или водишь пальцем по рабочему столу."
        hint.textSize = 16f
        val hintLp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        hintLp.topMargin = pad
        root.addView(hint, hintLp)

        val pick = Button(this)
        pick.text = "Выбрать фото"
        pick.setOnClickListener { pickPhoto() }
        val btnLp1 = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        btnLp1.topMargin = pad
        root.addView(pick, btnLp1)

        val set = Button(this)
        set.text = "Поставить живые обои"
        set.setOnClickListener { setWallpaper() }
        val btnLp2 = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        btnLp2.topMargin = pad / 2
        root.addView(set, btnLp2)

        status = TextView(this)
        status.textSize = 16f
        val stLp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        stLp.topMargin = pad
        root.addView(status, stLp)

        setContentView(root)
        refreshStatus()
    }

    private fun refreshStatus() {
        val has = File(filesDir, "photo.jpg").exists()
        status.text = if (has) "Фото выбрано." else "Фото пока нет, будет простой градиент."
    }

    private fun pickPhoto() {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = "image/*"
        i.addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(Intent.createChooser(i, "Фото"), pickCode)
    }

    private fun setWallpaper() {
        try {
            val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            i.putExtra(
                WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                ComponentName(this, JellyWallpaperService::class.java)
            )
            startActivity(i)
        } catch (e: ActivityNotFoundException) {
            try {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            } catch (e2: Exception) {
                status.text = "Не удалось открыть выбор обоев. Открой Настройки, Обои, Живые обои."
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickCode && resultCode == RESULT_OK) {
            val uri = data?.data
            if (uri != null && importPhoto(uri)) {
                status.text = "Фото сохранено. Теперь жми \"Поставить живые обои\"."
            } else {
                status.text = "Не удалось открыть это фото."
            }
        }
    }

    private fun importPhoto(uri: Uri): Boolean {
        try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false

            var sample = 1
            while (bounds.outWidth / sample > 2400 || bounds.outHeight / sample > 2400) sample *= 2
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            var bmp = contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return false

            var degrees = 0f
            try {
                contentResolver.openInputStream(uri)?.use {
                    val exif = ExifInterface(it)
                    when (exif.getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                    )) {
                        ExifInterface.ORIENTATION_ROTATE_90 -> degrees = 90f
                        ExifInterface.ORIENTATION_ROTATE_180 -> degrees = 180f
                        ExifInterface.ORIENTATION_ROTATE_270 -> degrees = 270f
                    }
                }
            } catch (e: Exception) {
                degrees = 0f
            }
            if (degrees != 0f) {
                val m = Matrix()
                m.postRotate(degrees)
                val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                bmp.recycle()
                bmp = rotated
            }

            File(filesDir, "photo.jpg").outputStream().use {
                bmp.compress(Bitmap.CompressFormat.JPEG, 92, it)
            }
            bmp.recycle()
            return true
        } catch (e: Exception) {
            return false
        }
    }
}
